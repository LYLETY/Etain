﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using EtainTest.Models;
using Newtonsoft.Json.Linq;

namespace EtainTest.ViewModels
{
    public class WeatherResultViewModel
    {
        public List<Weather> WeatherRecords { get; set; }

        public WeatherResultViewModel()
        {
            WeatherRecords = new List<Weather>();
        }

        //ConvertApiDataToWeatherRecords
        public WeatherResultViewModel(JObject jObject)
        {
            WeatherRecords = new List<Weather>();
            var consolidatedWeather = JArray.Parse(jObject["consolidated_weather"].ToString());

            for (var i = 0; i < consolidatedWeather.Count - 1; i++)
            {
                WeatherRecords.Add(new Weather
                {
                    Date = DateTime.Parse(consolidatedWeather[i]["applicable_date"].ToString()),
                    WeatherState = consolidatedWeather[i]["weather_state_name"].ToString(),
                    WeatherStateIcon = consolidatedWeather[i]["weather_state_abbr"].ToString()
                });
            }
        }
    }
}

