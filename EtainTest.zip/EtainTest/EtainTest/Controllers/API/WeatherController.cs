﻿using EtainTest.Models;
using EtainTest.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace EtainTest.Controllers.API
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class WeatherController : ControllerBase
    {
        public const string Belfast = "Belfast";
        private readonly IConfiguration _configuration;

        public WeatherController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpGet]
        public WeatherResultViewModel GetWeatherResultsForNextFiveDays()
        {
            var weatherModel = new Weather();
            var cityWeatherDownloadedData = weatherModel.GetCityWeatherData(Belfast);

            return new WeatherResultViewModel(cityWeatherDownloadedData);
        }
    }
}