﻿using System;
using System.Net;
using System.Text;
using EtainTest.Interfaces;
using Newtonsoft.Json.Linq;

namespace EtainTest.Models
{
    public class Weather : IWeatherDataCollector
    {
        public DateTime? Date { get; set; }
        public string WeatherState { get; set; }
        public string WeatherStateIcon { get; set; }

        public string City => "Belfast";


        public JObject GetCityWeatherData(string city)
        {
            using (var webClient = new WebClient())
            {
                try
                {
                    var metaWeatherCityDetails =
                        webClient.DownloadData($"{ApiUrl.MetaWeatherApiFindCityUrl}{City}");

                    var cityDetails = JArray.Parse(Encoding.ASCII.GetString(metaWeatherCityDetails));

                    var metaWeatherCityWoeId = cityDetails[0]["woeid"].ToString();

                    var downloadedCityWeatherData =
                        webClient.DownloadData($"{ApiUrl.MetaWeatherApiFindWoeIdUrl}{metaWeatherCityWoeId}");

                    return JObject.Parse(Encoding.ASCII.GetString(downloadedCityWeatherData));
                }
                catch(Exception ex)
                {
                    throw new Exception($"MetaWeather did not return any results for {City} : {ex.Message} ");
                }

            }
        }

    }
}
