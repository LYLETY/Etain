﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EtainTest.Models
{
    public class ApiUrl
    {
        public const string MetaWeatherApiFindCityUrl = "https://www.metaweather.com/api/location/search/?query=";
        public const string MetaWeatherApiFindWoeIdUrl = "https://www.metaweather.com/api/location/";
    }
}
