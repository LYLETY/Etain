﻿using Newtonsoft.Json.Linq;

namespace EtainTest.Interfaces
{
    public interface IWeatherDataCollector
    {
        JObject GetCityWeatherData(string city);
    }
}
